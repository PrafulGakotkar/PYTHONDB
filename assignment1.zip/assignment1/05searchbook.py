from contextlib import nullcontext
import pymysql


con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
curs=con.cursor()
bckd=input("enter the bookcode you want to search: ")
curs.execute("select * from Books where bookcode=%s" %bckd)
data=curs.fetchone()
try:
    print('Book code      : %s' %data[0])
    print('Book Name      : %s' %data[1])
    print('Category       : %s' %data[2])
    print('Author         : %s' %data[3])
    print('Publication    : %s' %data[4])
    print('Edition        : %s' %data[5])
    print('Price          : %s' %data[6])
except:
    print('Book does not exist')

con.close()