import pymysql

cat=input("Enter the category of Books you Want to see: ")
con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
curs=con.cursor()

try:
  curs.execute("select * from Books where Category='%s' " %cat)
  data=curs.fetchall()
  print(data)

  con.close()

except Exception as e:
    print(e)  

