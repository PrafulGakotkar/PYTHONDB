import pymysql


con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
curs=con.cursor()
bkcd=input("Enter the Book code: ")
curs.execute("select * from Books where Bookcode='%s'" %bkcd)
data=curs.fetchone()
try:
    print("Book name : '%s'" %data[1])
    rw=input("enter the review of book: ")
    curs.execute("update Books set review ='%s' where Bookcode='%s'" %(rw,bkcd))
    print("Review uploaded successfully")
    con.commit()
except Exception as e:
    print(e)  

con.close()
