import pymysql


con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
curs=con.cursor()

try:
    code=input("Enter book code : ")
    curs.execute("select * from Books where Bookcode='%s'" %code)
    #data=curs.fetchone()
    nprice=int(input("Enter new price"))
    curs.execute("update Books set price=%d where Bookcode='%s'" %(nprice,code))
    con.commit()
    print("update successfully")
    con.close()
except Exception as e:
    print(e)    