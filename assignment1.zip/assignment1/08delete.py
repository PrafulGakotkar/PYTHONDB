import pymysql


con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
curs=con.cursor()

try:
    code=input("Enter book code : ")
    curs.execute("select * from Books where Bookcode='%s'" %code)
    data=curs.fetchone()
    if data:
        n=input("do you want to delete ?(yes / no)")
        if n.lower() =='yes':
            curs.execute("delete from Books where Bookcode='%s' " %code)
            con.commit()
            print("delete record successfully")
    else:
        print("Book does not found")
except Exception as e:
    print(e)                 
