import pymysql


con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
curs=con.cursor()
author=input("Enter Author Name: ")
publi=input("Enter the Name of the Publication: ")

try:
   curs.execute("select * from Books where Author='%s' And Publication='%s' "%(author,publi))
   data=curs.fetchall()
   #for rec in data:
   print(data)

   con.close()

except Exception as e:
    print(e)   