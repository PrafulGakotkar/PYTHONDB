import pymysql

try:
    con=pymysql.connect(host='br9vwl9trfid9gbnuvbc-mysql.services.clever-cloud.com', user='ujvztseadnin1jj3', password='rpkpvmrje2bMhaQvUOPw',database='br9vwl9trfid9gbnuvbc')
    curs=con.cursor()
    bkcd=input("Enter the book code: ")
    bknm=input("Enter the Book Name: ")
    Cate=input("Enter the books category: ")
    author=input("ENter the Name of author of book: ")
    publ=input("Enter the name of publicatiopn: ")
    edition=input("Enter the edition of book: ")
    price=int(input("Enter the price of book: "))
    
    curs.execute("insert into Books values(%s,'%s','%s','%s','%s','%s',%d)" %(bkcd,bknm,Cate,author,publ,edition,price))
    con.commit()
    print("New Book is successfully Added")

    con.close()
except:
    print("failed")